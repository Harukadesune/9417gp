# Experimental code and saved evidence

Python 3.11 is required. Install the exact versions in requirements.txt.
The released CSV is not duplicated in this archive. Put the original course CSV at:
  data/nem_weather_halfhourly_2010_2026.csv
Do not substitute a different dataset.

Full reproduction from this directory:
  python -m pip install -r requirements.txt
  python reproduce.py

To browse saved evidence, open results_browser.ipynb. Run its cells to refresh saved views.
PROJECT_GUIDE.md documents the protocol and maps results and figures to experiment modules.
package/train.py rebuilds the final fitted artifacts only:
  python package/train.py data/nem_weather_halfhourly_2010_2026.csv

After any change to fitted models or model source, rebuild and check the exact ZIP:
  python build_deliverables.py
  python check_submission.py submission.zip

The existing final-14-day check log is results/submission_check.txt (2026-11-08).
Release assembly checked executable-code equivalence and identical fitted model hashes;
it did not rerun the prediction harness because the available environment is incomplete.
A fresh Linux sandbox run has not been claimed.

This archive contains experimental code, saved evidence and a technical guide.
It does not contain a student-authored report PDF or a leaderboard pseudonym.
